//
//  MealTableViewController.swift
//  MyFoodTracker
//
//  Created by apple on 2019/10/22.
//  Copyright © 2019 idup. All rights reserved.
//

import UIKit
import os.log

class MealTableViewController: UITableViewController {
    
    

    
    //MARK:Properties
    var sections = [[meal]]()
    
    func setSettions(){
        for _ in 0..<4{
            sections.append([meal]())
        }
    }
    
    func mymatchUrl(str:String)->[String]{
        let pattern = "<a href='(.*)' target="
        
        var StrList = [String]()
        let regex = try! NSRegularExpression(pattern: pattern, options: [])
        let matches = regex.matches(in: str, options: [], range:NSRange(str.startIndex...,in: str) )
        for  match in matches {
            var tmp = String(str[Range(match.range(at: 0), in: str)!]) as NSString
            var tmp1 = tmp.components(separatedBy: "'")
            //print(tmp1[1])
            if tmp1[1].hasPrefix("/"){
                tmp1[1] = "https://hr.nju.edu.cn/" + tmp1[1]
            }
            StrList.append(tmp1[1])
            
            }
        return StrList
    }
    
    func mymatchtitle(str:String)->[String]{
        let pattern = "title='(.*)'>"
        
        var StrList = [String]()
        let regex = try! NSRegularExpression(pattern: pattern, options: [])
        let matches = regex.matches(in: str, options: [], range:NSRange(str.startIndex...,in: str) )
        for  match in matches {
            var tmp = String(str[Range(match.range(at: 0), in: str)!]) as NSString
            var tmp1 = tmp.components(separatedBy: "'")
            //print(tmp1[1])
            StrList.append(tmp1[1])
            
            }
        return StrList
    }
    
    func mymatchDate(str:String)->[String]{
        let pattern = "\"news_meta\">(.*)</span>"
        
        var StrList = [String]()
        let regex = try! NSRegularExpression(pattern: pattern, options: [])
        let matches = regex.matches(in: str, options: [], range:NSRange(str.startIndex...,in: str) )
        for  match in matches {
            var tmp = String(str[Range(match.range(at: 0), in: str)!]) as NSString
            var tmp1 = tmp.components(separatedBy: ">")
            var tmp2 = tmp1[1] as NSString
            var tmp3 = tmp2.components(separatedBy: "<")
            //print(tmp3[0])
            StrList.append(tmp3[0])
            
            }
        return StrList
    }
    
    func mymatchNum(str:String)->[String]{
        let pattern = "news_meta1\"(.*)</span>"
        
        var StrList = [String]()
        let regex = try! NSRegularExpression(pattern: pattern, options: [])
        let matches = regex.matches(in: str, options: [], range:NSRange(str.startIndex...,in: str) )
        for  match in matches {
            var tmp = String(str[Range(match.range(at: 0), in: str)!]) as NSString
            var tmp1 = tmp.components(separatedBy: "(")
            var tmp2 = tmp1[1] as NSString
            var tmp3 = tmp2.components(separatedBy: ")")
            print(tmp3[0])
            StrList.append(tmp3[0])
            
            }
        return StrList
    }
    
    func loadData(){
        let dataSourceURL = URL(string:"https://hr.nju.edu.cn")!
        
        let request = URLRequest.init(url: dataSourceURL,cachePolicy: .useProtocolCachePolicy,timeoutInterval: 30)

        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: {(data, response, error) -> Void in
                if error != nil{
                        print(error.debugDescription)
                    }else{
                    let resultt = String(data: data!, encoding: String.Encoding.utf8) as! NSString
                    let resultALL = resultt.components(separatedBy: "<div class=\"tt\">")
                    for i in 1..<5{
                        let result = resultALL[i]
                        let pattern = "<li class=\"news.*</li>"
                        
                        var subStr = [String]()
                        let regex = try! NSRegularExpression(pattern: pattern, options: [])
                        let matches = regex.matches(in: result, options: [], range:NSRange(result.startIndex...,in: result) )
                        for  match in matches {
                            subStr.append(String(result[Range(match.range(at: 0), in: result)!]))
                            }
                        for str in subStr{
                            var StrList = [String]()
                            
                            StrList = StrList + self.mymatchUrl(str: str)
                            StrList = StrList + self.mymatchtitle(str: str)
                            StrList = StrList + self.mymatchDate(str: str)
                            StrList = StrList + self.mymatchNum(str: str)
                            
                            self.sections[i-1].append(meal(name: StrList[1], photo: UIImage(), date: StrList[2], url: StrList[0], num: Int(StrList[3])!)!)
                            
                        }
                    }
                    }
            self.tableView.reloadData()
        })
        task.resume()
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        setSettions()
        loadData()
        navigationItem.leftBarButtonItem = editButtonItem
        
    }

    // MARK: - Table view data source
    

    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return sections[section].count+1
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let reuseIdentifier = "MealTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as? MealTableViewCell else{
            fatalError("error")
        }
        if indexPath.row != 0{
            let mealTemp = sections[indexPath.section][indexPath.row-1]
        //print(indexPath.section)
        // Configure the cell...
            cell.nameLabel.text = mealTemp.name
            cell.photoImageView.image = mealTemp.photo
            cell.date.text = mealTemp.date
            cell.isUserInteractionEnabled = true
        }else{
            switch indexPath.section {
            case 0:
                cell.nameLabel.text = "人事通知"
            case 1:
                cell.nameLabel.text = "人事新闻"
            case 2:
                cell.nameLabel.text = "公示公告"
            case 3:
                cell.nameLabel.text = "招聘信息"
            default:
                cell.nameLabel.text = "\(indexPath.section)"
            }
            cell.isUserInteractionEnabled = false
            cell.photoImageView.image = nil
            cell.date.text = ""
        }
        return cell
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return false
    }

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        switch segue.identifier ?? "" {
        case "Additem":
            os_log("Add a new meal", log:OSLog.default, type: .debug)
            
        case "showDetail":
            guard let mealDetailViewControl = segue.destination as? MealViewController else {
                fatalError("\(segue.destination)")
            }
            guard let selectedMealCell = sender as? MealTableViewCell else {
                fatalError("\(sender)")
            }
            guard let indexPath = tableView.indexPath(for: selectedMealCell) else {
                fatalError("not display")
            }
            
            let selectedMeal = sections[indexPath.section][indexPath.row-1]
            mealDetailViewControl.mealHere = selectedMeal
        default:
            fatalError("\(segue.identifier)")
        }
    }
    
    //MARK:Private Methods
    
    @IBAction func unwindToMealList(sender:UIStoryboardSegue){
        if let sourceViewController = sender.source as? MealViewController, let mealHere = sourceViewController.mealHere{
            
            if let selectedIndexPath = tableView.indexPathForSelectedRow{
                sections[selectedIndexPath.section][selectedIndexPath.row-1] = mealHere
                tableView.reloadRows(at:[selectedIndexPath], with: .none)
            }else{
                let newIndexPath = IndexPath(row: sections[0].count, section: 0)
            
                sections[0].append(mealHere)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
        }
    }

}
