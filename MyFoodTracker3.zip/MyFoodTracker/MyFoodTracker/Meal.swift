//
//  Meal.swift
//  MyFoodTracker
//
//  Created by apple on 2019/10/22.
//  Copyright © 2019 idup. All rights reserved.
//

//import Foundation
import UIKit
import os.log

class meal:NSObject,NSCoding{
    //MARK:Types
    struct PropertyKey{
        static let name = "name"
        static let photo = "hot"
        static let date = "date"
        static let url = "url"
        static let num = "num"
    }
    
    //MARK:NSCoding
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: PropertyKey.name)
        aCoder.encode(photo, forKey: PropertyKey.photo)
        aCoder.encode(date, forKey: PropertyKey.date)
        aCoder.encode(url, forKey: PropertyKey.url)
        aCoder.encode(num, forKey: PropertyKey.num)
    }
    
    required convenience init?(coder aDecoder: NSCoder) {

        guard let name = aDecoder.decodeObject(forKey: PropertyKey.name) as? String else {
        os_log("Unable to decode the name for a Meal object.", log: OSLog.default, type: .debug)
        return nil
        }
        
        let photo = aDecoder.decodeObject(forKey: PropertyKey.photo) as? UIImage
        
        let date = aDecoder.decodeCInt(forKey: PropertyKey.date)
        
        self.init(name:name,photo:photo,date:String(date),url:"",num:0)
    }
    
    //MARK:Properties
    
    var name:String
    var photo:UIImage?
    var date:String
    var url:String
    var num:Int
    
    init?(name:String,photo:UIImage?,date:String,url:String,num:Int){
        self.name = name
        if num >= 1000{
            self.photo = UIImage(named: "fire")
        }
        self.date = date
        self.url = url
        self.num = num
    }
    
    //MARK:Archiving Paths
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("meals")
}
