//
//  MealViewController.swift
//  MyFoodTracker
//
//  Created by apple on 2019/10/14.
//  Copyright © 2019 idup. All rights reserved.
//

import UIKit
import WebKit
import MobileCoreServices
import AVFoundation
import os.log


class MealViewController: UIViewController,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    //MARK:Properties
    
    var dataSourceURL = URL(string:"https://hr.nju.edu.cn/")!
    
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var photoImageView: UIImageView!

    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    var mealHere:meal?
    
    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webView.load(URLRequest(url: URL(string: mealHere!.url)!))


    }
    //MARK:UITextFieldDelegate

    @IBAction func cancel(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
    }
    
    //MARK:Private method
    private func updateSaveButtonState() {
        // Disable the Save button if the text field is empty.
        let text = nameTextField.text ?? ""
        saveButton.isEnabled = !text.isEmpty
    }
    
}

