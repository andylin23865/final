//
//  MealTableViewCell.swift
//  MyFoodTracker
//
//  Created by apple on 2019/10/22.
//  Copyright © 2019 idup. All rights reserved.
//

import UIKit

class MealTableViewCell: UITableViewCell {
    
    //MARK:Properties
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var date: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
